# AICON2026_paper3

## Cach tai len

1. Overleaf -> **New Project** -> **Upload Project** -> chon file zip nay.
2. Bam **Recompile**. Xong.

Compiler: **pdfLaTeX**. `llncs.cls (Springer LNCS/LNICST)` co san tren Overleaf nen khong dong goi kem.

**Dung keo zip nay tha vao mot project Overleaf DANG CO.** Overleaf se giai
nen vao mot thu muc con, roi `main.tex` va cac thu muc con nam khac cho nhau
va bao thieu file. Phai la project MOI.

## Truoc khi nop qua EAI Confy+

- Giu `\anonymoustrue` trong `main.tex` -- Confy+ bat buoc PDF an danh.
- Thay dia chi kho ma bang mot mirror an danh
  (`anonymous.4open.science`): repo that mang ten tac gia.
- Khai xung dot loi ich: ba chair cua session deu la dong tac gia paper 1.

## Danh muc file

- `main.tex`  (33 KB)
- `tables/numbers_macros.tex`  (2 KB)
- `tables/degeneracy_census.tex`  (1 KB)
- `tables/objective_table.tex`  (2 KB)
- `figs/fig1_tuning_trap.pdf`  (30 KB)
- `figs/fig2_k_sweep.pdf`  (23 KB)
- `figs/fig3_objective.pdf`  (27 KB)


## Kiem trong repo truoc khi gui di

    python runners/make_paper3_figures.py
    python runners/make_paper3_tables.py
    python runners/audit_paper3.py
    python runners/check_latex.py paper/paper3_aicon/main.tex
