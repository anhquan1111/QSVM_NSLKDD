# Paper2_rebuild

## Cach tai len

1. Overleaf -> **New Project** -> **Upload Project** -> chon file zip nay.
2. Bam **Recompile**. Xong.

Compiler: **pdfLaTeX**. `IEEEtran.cls` co san tren Overleaf nen khong dong goi kem.

**Dung keo zip nay tha vao mot project Overleaf DANG CO.** Overleaf se giai
nen vao mot thu muc con, roi `main.tex` va cac thu muc con nam khac cho nhau
va bao thieu file. Phai la project MOI.

## Con phai lam truoc khi nop

- Viet prose o cac cho `% TODO` (mo bai, ket luan, chi tiet setup).
- Dien `thebibliography` -- giu danh muc cua ban da nop IJNM.
- Gui thay duyet: ban nay DOI TRUC chu dao so voi ban da nop.

## Danh muc file

- `main.tex`  (68 KB)
- `preamble.tex`  (3 KB)
- `tables/numbers_macros.tex`  (17 KB)
- `tables/main_table.tex`  (1 KB)
- `tables/percat_table.tex`  (1 KB)
- `tables/side_tables.tex`  (2 KB)
- `tables/depth_tables.tex`  (2 KB)
- `tables/regime_table.tex`  (1 KB)
- `biographies.tex`  (3 KB)
- `figs/fig1_identity.pdf`  (29 KB)
- `figs/fig2_paired.pdf`  (22 KB)
- `figs/fig5_reliability.pdf`  (31 KB)
- `figs/fig4_refarm.pdf`  (21 KB)
- `figs/fig3_platt.pdf`  (20 KB)
- `figs/fig6_threshold.pdf`  (26 KB)
- `authors/van.jpg`  (24 KB)
- `authors/vo.jpg`  (687 KB)
- `authors/nguyen.jpg`  (363 KB)
- `authors/pham.jpg`  (28 KB)


## Kiem trong repo truoc khi gui di

    python runners/make_p2_rebuild_figures.py
    python runners/make_p2_rebuild_tables.py
    python runners/audit_p2_rebuild.py
    python runners/verify_rare_identity.py
    python runners/check_latex.py paper/paper2_rebuild/main.tex
