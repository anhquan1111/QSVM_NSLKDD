# LaTeX source

Manuscript: "A Reliability and Calibration Benchmark of QSVM Against Strong
Tabular Learners on NSL-KDD and UNSW-NB15"

Compiler: pdfLaTeX.
Document class: IEEEtran (a standard TeX Live / Overleaf class; not bundled).
The reference list is a `thebibliography` environment inside `main.tex`, so no
BibTeX run is required.

## Files

  main.tex                    67 KB
  preamble.tex                 2 KB
  tables/numbers_macros.tex    17 KB
  tables/main_table.tex        1 KB
  tables/percat_table.tex      1 KB
  tables/side_tables.tex       2 KB
  tables/depth_tables.tex      2 KB
  tables/regime_table.tex      1 KB
  figs/fig1_identity.pdf      29 KB
  figs/fig2_paired.pdf        22 KB
  figs/fig5_reliability.pdf    31 KB
  figs/fig4_refarm.pdf        21 KB
  figs/fig3_platt.pdf         20 KB
  figs/fig6_threshold.pdf     26 KB

## Provenance

Every number and every figure in the manuscript is regenerated from the
artifacts archived at https://doi.org/10.5281/zenodo.22893683
